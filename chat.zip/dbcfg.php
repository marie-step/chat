<?php
// konfigurace pripojeni k DB
$server = "localhost";
$login = "root";
$passwd = "";
$schema = "chat";

?>
