<?php
define ("BR", "<br/>\n");
// TODO - postupne pridat dalsi konst.

?>