<?php
require_once "layout/header.php";
?>

<h1>Chat - vítejte</h1>


<?php
require_once "layout/footer.php";
?>
